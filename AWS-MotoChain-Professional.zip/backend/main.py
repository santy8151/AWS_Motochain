from fastapi import FastAPI
app=FastAPI(title="MotoChain AWS API")
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/prices/{brand}")
def prices(brand:str):
    return {"brand":brand,"source":"scraper-ready","mercadolibre":f"https://listado.mercadolibre.com.co/{brand}-motos"}
